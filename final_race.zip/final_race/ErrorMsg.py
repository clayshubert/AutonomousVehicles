class ErrorMsg:
	float
		#float64 X_One
		#float64 Height_Of_Cone
		#float64 Area_Of_View_Top
		#float64 Area_Of_View_Bottom
		#bool Stop_Now
